package com.AdmirabletyRate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdmirabletyRateApplicationTests {

	@Test
	void contextLoads() {
	}

}
