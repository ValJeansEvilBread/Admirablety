package com.AdmirabletyRate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdmirabletyRateApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdmirabletyRateApplication.class, args);
	}

}
